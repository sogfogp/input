package com.playedstore

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

data class Repo(val name: String, val base: String, val index: String, val priority: Int)
data class StoreApp(
    val packageName: String, val name: String, val summary: String,
    val versionName: String, val versionCode: Long, val apkName: String,
    val sha256: String, val repo: Repo
)

private val repos = listOf(
    Repo("F-Droid", "https://f-droid.org/repo/", "https://f-droid.org/repo/index-v1.json", 0),
    Repo("IzzyOnDroid", "https://apt.izzysoft.de/fdroid/repo/", "https://apt.izzysoft.de/fdroid/repo/index-v1.json", 1)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppHolder.context = applicationContext
        setContent { PlayedStoreScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayedStoreScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var apps by remember { mutableStateOf<List<StoreApp>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Loading repositories…") }
    var loading by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<StoreApp?>(null) }
    var apkCubeKey by remember { mutableStateOf("") }
    var apkCubeCredits by remember { mutableStateOf<Int?>(null) }
    var apkCubeConnected by remember { mutableStateOf(false) }
    var apkCubeBusy by remember { mutableStateOf(false) }

    fun checkApkCubeKey() {
        val key = apkCubeKey.trim()
        if (key.isBlank()) {
            status = "Enter your own APKCube API key first."
            return
        }
        scope.launch {
            apkCubeBusy = true
            try {
                val account = withContext(Dispatchers.IO) { ApkCubeClient.getAccount(key) }
                apkCubeCredits = account.optInt("credits", -1).takeIf { it >= 0 }
                apkCubeConnected = true
                status = "APKCube connected. Credit balance: ${apkCubeCredits ?: "unknown"}."
            } catch (e: Exception) {
                apkCubeConnected = false
                apkCubeCredits = null
                status = "APKCube connection failed: ${e.message ?: "unknown error"}"
            } finally {
                apkCubeBusy = false
            }
        }
    }

    fun refresh() {
        scope.launch {
            loading = true
            status = "Updating F-Droid and IzzyOnDroid…"
            try {
                val fetched = withContext(Dispatchers.IO) { RepositoryClient.loadAll() }
                apps = fetched
                status = "${fetched.size} apps indexed from ${repos.size} repositories"
            } catch (e: Exception) {
                status = "Could not load repositories: ${e.message ?: "network error"}"
            } finally { loading = false }
        }
    }

    LaunchedEffect(Unit) { refresh() }

    val filtered = remember(apps, query) {
        apps.filter {
            it.name.contains(query, true) ||
            it.packageName.contains(query, true) ||
            it.summary.contains(query, true)
        }.sortedBy { it.name.lowercase() }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF176B45))) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Played Store", fontWeight = FontWeight.Bold) },
                    actions = {
                        TextButton(onClick = { refresh() }, enabled = !loading) { Text("Refresh") }
                    }
                )
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
                OutlinedTextField(
                    value = query, onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                    placeholder = { Text("Search apps") },
                    singleLine = true
                )
                Spacer(Modifier.height(8.dp))
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("APKCube source (optional)", fontWeight = FontWeight.SemiBold)
                        OutlinedTextField(
                            value = apkCubeKey,
                            onValueChange = {
                                apkCubeKey = it
                                apkCubeConnected = false
                                apkCubeCredits = null
                            },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            placeholder = { Text("Your personal APKCube API key") },
                            label = { Text("API key") }
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Button(onClick = { checkApkCubeKey() }, enabled = !apkCubeBusy && apkCubeKey.isNotBlank()) {
                                Text(if (apkCubeBusy) "Checking…" else "Connect")
                            }
                            Spacer(Modifier.width(10.dp))
                            Text(
                                if (apkCubeConnected) "Connected · ${apkCubeCredits ?: "?"} credits"
                                else "Not connected",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            "Key stays in memory only. Build lookup costs 1 credit; an APK download costs 10 more. No automatic paid fetches.",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(status, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Sources: F-Droid • IzzyOnDroid • optional APKCube for matching catalogue packages",
                    style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                if (loading && apps.isEmpty()) {
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                }
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(filtered, key = { it.packageName }) { app ->
                        ElevatedCard(Modifier.fillMaxWidth().clickable { selected = app }) {
                            Column(Modifier.padding(14.dp)) {
                                Text(app.name, fontWeight = FontWeight.SemiBold)
                                Text(app.summary, style = MaterialTheme.typography.bodySmall, maxLines = 2)
                                Spacer(Modifier.height(4.dp))
                                Text("${app.versionName} • ${app.repo.name}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
        }
    }

    selected?.let { app ->
        AlertDialog(
            onDismissRequest = { selected = null },
            title = { Text(app.name) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(app.summary)
                    Text("Package: ${app.packageName}", style = MaterialTheme.typography.bodySmall)
                    Text("Version: ${app.versionName} (${app.versionCode})", style = MaterialTheme.typography.bodySmall)
                    Text("Selected source: ${app.repo.name}", style = MaterialTheme.typography.bodySmall)
                    Text("APK hash: ${app.sha256.take(16)}…", style = MaterialTheme.typography.bodySmall)
                    Text("Google Play is available for listing lookup only; it does not provide an anonymous public APK download API.",
                        style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = {
                Column(horizontalAlignment = Alignment.End) {
                    TextButton(onClick = {
                        val chosen = app
                        selected = null
                        scope.launch {
                            status = "Downloading and checking ${chosen.name}…"
                            try {
                                val file = withContext(Dispatchers.IO) { RepositoryClient.downloadVerified(chosen) }
                                installApk(context, file)
                                status = "Downloaded. Android will ask you to confirm installation."
                            } catch (e: Exception) {
                                status = "Install preparation failed: ${e.message ?: "unknown error"}"
                            }
                        }
                    }) { Text("Install from ${app.repo.name}") }
                    TextButton(
                        enabled = apkCubeConnected && !apkCubeBusy,
                        onClick = {
                            val chosen = app
                            val key = apkCubeKey.trim()
                            selected = null
                            apkCubeBusy = true
                            scope.launch {
                                status = "Checking APKCube build and preparing download…"
                                try {
                                    val result = withContext(Dispatchers.IO) {
                                        ApkCubeClient.downloadExistingApk(chosen.packageName, key)
                                    }
                                    apkCubeCredits = result.creditsRemaining ?: apkCubeCredits
                                    installApk(context, result.file)
                                    status = "APKCube APK verified (SHA-256) and downloaded. Android will ask you to confirm installation."
                                } catch (e: Exception) {
                                    status = "APKCube: ${e.message ?: "download failed"}"
                                } finally {
                                    apkCubeBusy = false
                                }
                            }
                        }
                    ) { Text("APKCube download · up to 11 credits") }
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    val url = "https://play.google.com/store/apps/details?id=${Uri.encode(app.packageName)}"
                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                }) { Text("Play Store listing") }
            }
        )
    }
}


private fun installApk(context: android.content.Context, file: File) {
    if (android.os.Build.VERSION.SDK_INT >= 26 &&
        !context.packageManager.canRequestPackageInstalls()) {
        val settingsIntent = Intent(
            android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
            Uri.parse("package:${context.packageName}")
        )
        context.startActivity(settingsIntent)
        return
    }
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
    val intent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uri, "application/vnd.android.package-archive")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(intent)
}

private data class ApkCubeDownload(val file: File, val creditsRemaining: Int?)

private object ApkCubeClient {
    private const val API = "https://apkcube.com/api/v1"

    fun getAccount(apiKey: String): JSONObject = apiJson("GET", "/me", apiKey)

    fun downloadExistingApk(packageName: String, apiKey: String): ApkCubeDownload {
        require(apiKey.isNotBlank()) { "API key is missing." }
        val safePackage = packageName.split(".").joinToString(".") { Uri.encode(it) }

        // This lookup costs 1 credit. Never request a fetch automatically:
        // APKCube charges 10 credits for a fetch even if the app cannot be obtained.
        val versionsJson = apiJson("GET", "/apps/$safePackage/versions", apiKey)
        val versions = versionsJson.optJSONArray("versions")
            ?: throw IllegalStateException("APKCube returned no versions list.")
        if (versions.length() == 0) {
            throw IllegalStateException("APKCube has no stored build. No paid fetch was requested.")
        }

        val latest = versions.optJSONObject(0)
            ?: throw IllegalStateException("APKCube returned an invalid version record.")
        val format = latest.optString("format")
        if (format != "apk") {
            throw IllegalStateException("The newest build is $format (a split bundle). This version of Played Store only installs single APK files.")
        }

        val apkId = latest.optString("apkId")
        val body = JSONObject()
        if (apkId.isNotBlank()) body.put("apkId", apkId)

        // This download call costs 10 credits.
        val mint = apiJson("POST", "/apps/$safePackage/download", apiKey, body)
        val downloadFormat = mint.optString("format")
        if (downloadFormat != "apk") {
            throw IllegalStateException("APKCube returned $downloadFormat, not a single APK.")
        }
        val expectedHash = mint.optString("sha256").lowercase()
        require(expectedHash.matches(Regex("[0-9a-f]{64}"))) {
            "APKCube did not provide a valid SHA-256 checksum."
        }
        val url = mint.optString("url")
        require(url.startsWith("https://")) { "APKCube returned an invalid download URL." }

        val bytes = httpBytes(url)
        val actualHash = MessageDigest.getInstance("SHA-256").digest(bytes)
            .joinToString("") { "%02x".format(it) }
        require(actualHash == expectedHash) { "Downloaded APK failed SHA-256 verification." }

        val dir = File(AppHolder.context.cacheDir, "apks").apply { mkdirs() }
        val file = File(dir, "apkcube-$packageName-${mint.optLong("versionCode")}.apk")
        file.writeBytes(bytes)
        val credits = mint.optInt("creditsRemaining", -1).takeIf { it >= 0 }
        return ApkCubeDownload(file, credits)
    }

    private fun apiJson(method: String, path: String, apiKey: String, body: JSONObject? = null): JSONObject {
        val connection = (URL(API + path).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 20000
            readTimeout = 30000
            setRequestProperty("Authorization", "Bearer $apiKey")
            setRequestProperty("Accept", "application/json")
            if (method == "POST") {
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
            }
        }
        return try {
            if (method == "POST") {
                connection.outputStream.use { it.write((body ?: JSONObject()).toString().toByteArray()) }
            }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            val json = if (response.isBlank()) JSONObject() else JSONObject(response)
            if (code !in 200..299) {
                val error = json.optJSONObject("error")
                throw IllegalStateException(error?.optString("message")?.takeIf { it.isNotBlank() }
                    ?: "HTTP $code")
            }
            json
        } finally {
            connection.disconnect()
        }
    }

    private fun httpBytes(urlString: String): ByteArray {
        val connection = (URL(urlString).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20000
            readTimeout = 60000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "PlayedStore/0.2 (Android)")
        }
        return try {
            require(connection.responseCode in 200..299) { "APKCube file server returned HTTP ${connection.responseCode}" }
            connection.inputStream.use { it.readBytes() }
        } finally {
            connection.disconnect()
        }
    }
}

private object RepositoryClient {
    fun loadAll(): List<StoreApp> {
        val all = mutableListOf<StoreApp>()
        repos.forEach { repo ->
            val json = JSONObject(httpGet(repo.index))

            // F-Droid v1 indexes store package versions in an object:
            // "packages": { "org.example.app": [ { ...version... } ] }
            // App display metadata is stored separately in "apps".
            val appNames = mutableMapOf<String, Pair<String, String>>()
            val appArray = json.optJSONArray("apps")
            if (appArray != null) {
                for (i in 0 until appArray.length()) {
                    val a = appArray.optJSONObject(i) ?: continue
                    val id = a.optString("packageName")
                    if (id.isNotBlank()) {
                        appNames[id] = a.optString("name", id) to a.optString("summary", "")
                    }
                }
            }

            val packages = json.optJSONObject("packages") ?: continue
            val keys = packages.keys()
            while (keys.hasNext()) {
                val id = keys.next()
                val versions = packages.optJSONArray(id) ?: continue
                val meta = appNames[id] ?: (id to "")
                for (i in 0 until versions.length()) {
                    val p = versions.optJSONObject(i) ?: continue
                    val apk = p.optString("apkName")
                    val hash = p.optString("hash")
                    val versionCode = p.optLong("versionCode", -1L)
                    if (apk.isBlank() || hash.length != 64 || versionCode < 0L) continue
                    all += StoreApp(
                        packageName = id,
                        name = meta.first,
                        summary = meta.second,
                        versionName = p.optString("versionName", ""),
                        versionCode = versionCode,
                        apkName = apk,
                        sha256 = hash.lowercase(),
                        repo = repo
                    )
                }
            }
        }

        // Deduplicate package IDs. Prefer the highest version; on a tie,
        // prefer the repository with the better configured priority.
        return all.groupBy { it.packageName }.values.mapNotNull { candidates ->
            candidates.sortedWith(
                compareByDescending<StoreApp> { it.versionCode }
                    .thenBy { it.repo.priority }
            ).firstOrNull()
        }.sortedBy { it.name.lowercase() }
    }

    fun downloadVerified(app: StoreApp): File {
        val bytes = httpBytes(app.repo.base + Uri.encode(app.apkName, "/"))
        val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
            .joinToString("") { "%02x".format(it) }
        require(digest.equals(app.sha256, ignoreCase = true)) {
            "APK SHA-256 does not match repository index"
        }
        val dir = File(AppHolder.context.cacheDir, "apks").apply { mkdirs() }
        val file = File(dir, "${app.packageName}-${app.versionCode}.apk")
        file.writeBytes(bytes)
        return file
    }

    private fun httpGet(url: String) = String(httpBytes(url), Charsets.UTF_8)

    private fun httpBytes(urlString: String): ByteArray {
        val connection = (URL(urlString).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20000
            readTimeout = 30000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "PlayedStore/0.1 (Android)")
        }
        return try {
            require(connection.responseCode in 200..299) { "HTTP ${connection.responseCode}" }
            connection.inputStream.use { it.readBytes() }
        } finally {
            connection.disconnect()
        }
    }
}

// Avoid passing Activity references into repository code; cache path is set by the app at startup.
private object AppHolder { lateinit var context: android.content.Context }
